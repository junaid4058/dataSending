//
//  PopOverViewController.swift
//  stackSwift
//
//  Created by junaid on 6/8/17.
//  Copyright © 2017 junaid. All rights reserved.
//

import UIKit

var SCREEN_WIDTH = UIScreen.main.bounds.size.width
var SCREEN_HEIGHT = UIScreen.main.bounds.size.height
var BASE_SCREEN_WIDTH:CGFloat = 375.0
var BASE_SCREEN_HEIGHT:CGFloat = 667.0
var SCREEN_MAX_LENGTH = max(SCREEN_WIDTH, SCREEN_HEIGHT)
var ASPECT_RATIO_RESPECT_OF_7P = SCREEN_HEIGHT / BASE_SCREEN_HEIGHT
var HEIGHT_ASPECT_RATIO = SCREEN_HEIGHT/BASE_SCREEN_HEIGHT
var WIDTH_ASPECT_RATIO = SCREEN_WIDTH/BASE_SCREEN_WIDTH
class PopOverViewController: UIViewController,UIPopoverPresentationControllerDelegate {
    
    var popoverSize:CGSize = CGSize.zero
    var popController:UIPopoverPresentationController? = nil
    @IBOutlet weak var menuBtn: UIBarButtonItem!
    var arrayOfAnyObject: [Any] = [Any]()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        popoverSize.width = 200
        popoverSize.height = 200
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showPopUp(_ sender: Any) {
        self.configurePopOver()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuAction(_ sender: Any) {
 
        self.configurePopOver()
        
    }
    

    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return .none
    }
    
    func configurePopOver() {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "pop")
        viewController.modalPresentationStyle = .popover
        viewController.preferredContentSize = popoverSize//CGSize.init(width: self.view.bounds.size.width, height: 200)
        
        
        popController = viewController.popoverPresentationController
        popController?.permittedArrowDirections = .down //For bar button menu must select .any
        popController?.backgroundColor = UIColor.gray
        //popController?.barButtonItem = menuBtn
        popController?.delegate = self
        popController?.sourceView = self.view
        popController?.sourceRect = CGRect.init(x:16 , y: 627*HEIGHT_ASPECT_RATIO, width:10, height: 10)
        self.present(viewController, animated: true, completion: nil)
    
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        SCREEN_WIDTH = size.width
        SCREEN_HEIGHT = size.height
        popController?.permittedArrowDirections = .down
        HEIGHT_ASPECT_RATIO = SCREEN_HEIGHT/BASE_SCREEN_HEIGHT
        WIDTH_ASPECT_RATIO = SCREEN_WIDTH/BASE_SCREEN_WIDTH
        popoverSize.width = 200
        popoverSize.height = 200
        popController?.sourceRect = CGRect.init(x:16 , y: 500*HEIGHT_ASPECT_RATIO, width:10, height: 10)
        
    }
}
