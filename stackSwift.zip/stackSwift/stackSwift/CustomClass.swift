//
//  CustomClass.swift
//  stackSwift
//
//  Created by junaid on 6/5/17.
//  Copyright © 2017 junaid. All rights reserved.
//

import UIKit

class CustomClass: UIView {

    @IBOutlet weak var bigLabel: UILabel!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    class func loadNib() ->String {
        return NSStringFromClass(CustomClass.self)
    }


    
    

}
extension UIView {
    class func fromNib<T : UIView>() -> T {
        return Bundle.main.loadNibNamed(String(describing: T.self), owner: nil, options: nil)![0] as! T
    }
}
