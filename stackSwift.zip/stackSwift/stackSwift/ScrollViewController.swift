//
//  ScrollViewController.swift
//  stackSwift
//
//  Created by junaid on 6/2/17.
//  Copyright © 2017 junaid. All rights reserved.
//

import UIKit
import SDWebImage

class ScrollViewController: UIViewController,UIScrollViewDelegate {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var customLabel: UILabel!

    @IBOutlet weak var scrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        
        
        self.customLabel.text = "When your head is on the pillow and the day is almost done count ALlah's name count htem one by one."
        self.customLabel.roundCorners(corners: [.topLeft,.topRight,.bottomLeft], radius: 7.0)
        self.customLabel.layoutIfNeeded()
 

        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    

    @IBAction func grabImage(_ sender: Any) {
       //  imageView.sd_setImage(with: URL(string: "https://static.pexels.com/photos/115045/pexels-photo-115045.jpeg"), placeholderImage: UIImage(named: "1"))
        
        self.customLabel.text = "When your head is on the pillow and the day is almost done count ALlah's name count htem one by one."
        self.customLabel.roundCorners(corners: [.topLeft,.topRight,.bottomLeft], radius: 10)
        
    }
}
extension UIView {
    func roundCorners(corners:UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}
