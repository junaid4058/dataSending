//
//  ViewController.swift
//  stackSwift
//
//  Created by junaid on 5/30/17.
//  Copyright © 2017 junaid. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    
    var images:[String] = []
    var timer = Timer()
    var photoCount:Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        images = ["1","2","3"]
        imageView.image = UIImage.init(named: "1")
        timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(onTransition), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addText(_ sender: Any) {
        
        
    }
    
    func onTransition() {
        if (photoCount < images.count - 1){
            photoCount = photoCount  + 1;
        }else{
            photoCount = 0;
        }
        
        UIView.transition(with: self.imageView, duration: 2.0, options: .transitionCrossDissolve, animations: { 
            self.imageView.image = UIImage.init(named: self.images[self.photoCount])
        }, completion: nil)
    }

}

