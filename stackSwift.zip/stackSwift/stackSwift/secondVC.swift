//
//  secondVC.swift
//  stackSwift
//
//  Created by junaid on 6/8/17.
//  Copyright © 2017 junaid. All rights reserved.
//

import UIKit

class secondVC: UIViewController {
    
    @IBOutlet weak var textlabel: UILabel!
    var stringHolder:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textlabel.text = stringHolder

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
